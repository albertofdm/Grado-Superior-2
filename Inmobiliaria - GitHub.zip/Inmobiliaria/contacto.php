<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Formulario de Contacto Inmobiliaria | Inmobiliaria Afm y Manu</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/bootstrap-theme.css" rel="stylesheet">
	<link rel="stylesheet" href="css/contacto.css">

	<style>

body{

font-family: "Poppins", sans-serif;
}

.btn-primary{

    margin-top: -15px;
    margin-bottom: 15px;
    width: 25%;
    margin-left: 8px;

}
		</style>
</head>

<body>

	<section class="form-contact">
		<header>
			<span>
				<i class="fa fa-paper-plane" aria-hidden="true"></i>
			</span>
		</header>

		<form action="" class="contact" method="POST">
			<label for="nombres">Nombre</label>
			<input type="text" name="nombres" id="nombres">

			<label for="correo">Correo</label>
			<input type="text" name="correo" id="correo">

			<label for="nombres">Teléfono</label>
			<input type="text" name="telefono" id="telefono">

			<label for="nombres">Asunto</label>
			<input type="text" name="asunto" id="asunto">

			<label for="mensaje">Mensaje</label>
			<textarea name="mensaje" id="mensaje"></textarea>
			<input type="submit" value="Enviar" id="enviar" onclick="comprobar()">

			
		</form>
		<br><a href="index.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>
	</section>

</body>

</html>


<script languaje="JavaScript">
	function comprobar() {

		var nombre = document.getElementById("nombres").value;

		var correo = document.getElementById("correo").value;

		var telefono = document.getElementById("telefono").value;

		var asunto = document.getElementById("asunto").value;

		var mensaje = document.getElementById("mensaje").value;
	

		if (nombre == "") {

			alert("Debes rellenar el campo nombre")

			document.getElementById("nombre").focus()
			return 0
		}

		if (nombre.length <= 3) {

			alert("El campo nombre debe tener mas de 3 caracteres")

			document.getElementById("nombre").focus()
			return 0
		}

		if (correo == "") {

			alert("Debes rellenar el campo Email")

			document.getElementById("correo").focus()
			return 0
		}

		if ((correo.includes("@") == false)) {
			alert("El correo tiene que tener un @");
			document.getElementById("telefono").focus();
			return 0
		}

		if (telefono == "") {

			alert("Debes rellenar el campo telefono")

			document.getElementById("telefono").focus()
			return 0
		}

		if (telefono.length <= 3) {

			alert("El campo telefono debe tener mas de 3 caracteres")

			document.getElementById("telefono").focus()
			return 0
		}



		if (asunto == "") {

			alert("Es obligatorio rellenar el campo asunto")

			document.getElementById("asunto").focus()
			return 0

		}

		if (asunto.length <= 3) {

			alert("El campo asunto debe tener mas de 3 caracteres")

			document.getElementById("asunto").focus()
			return 0

		}

		if (mensaje == "") {

			alert("Es obligatorio rellenar el campo Mensaje")

			document.getElementById("mensaje").focus()
			return 0

		}

		if (mensaje.length <= 10) {

			alert("El campo mensaje debe contener mas de 20 caracteres")

			document.getElementById("mensaje").focus()
			return 0

		}else{

			alert("Su mensaje ha sido enviado correctamente.")
		}

	}
</script>