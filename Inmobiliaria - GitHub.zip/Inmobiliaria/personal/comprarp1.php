<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>
<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}


    </style>
</head>
    <?PHP
    if(isset($_SESSION['personal_login']))
    {

            $mail= $_SESSION['personal_login'];


    }




    $id=$_REQUEST['elegido'];
    $user=$_REQUEST['user'];

    // Conectar con el servidor de base de datos
    $conexion = mysqli_connect ("localhost", "root", "rootroot")
    or die ("No se puede conectar con el servidor");

    // Seleccionar base de datos
    mysqli_select_db ($conexion,"inmobiliaria")
    or die ("No se puede seleccionar la base de datos");
    // Enviar consulta
    $instruccion = "select * from pisos where Codigo_piso like $id";

    $consulta = mysqli_query ($conexion,$instruccion)
    or die ("Fallo en la consulta");
    // Mostrar resultados de la consulta
    $nfilas = mysqli_num_rows ($consulta);
    if ($nfilas > 0)
    {
    $resultado = mysqli_fetch_array ($consulta); 
        $precio= $resultado['precio'];

    }

    else {
    print ("No hay noticias disponibles");
    }
    // Cerrar 
    mysqli_close ($conexion);



    $resultado = mysqli_fetch_array ($consulta);


   // Conectar con el servidor de base de datos
      $conexion = mysqli_connect ("localhost", "root", "rootroot")
         or die ("No se puede conectar con el servidor");
		 
   // Seleccionar base de datos
      mysqli_select_db ($conexion,"inmobiliaria")
         or die ("No se puede seleccionar la base de datos");
   // Enviar consulta

    $consulta = mysqli_query ($conexion,"insert into comprados values($user,$id,$precio)");


    Echo 'El piso con ID: ' . $id . 'ha sido comprado';
// Cerrar 
mysqli_close ($conexion);


?>

<br><br><a href="personal_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>