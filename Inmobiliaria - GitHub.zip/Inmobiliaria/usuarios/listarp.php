<HTML LANG="es">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<HEAD>


<style>

body{
    background-color: #c1bdba;
color:black;
font-family: "Poppins", sans-serif;
}

form{

   font-family: "Poppins", sans-serif;
    margin-left: 850px;
    margin-top: 60px;

}
h1{
    margin-top:40px;
    font-family: "Poppins", sans-serif;
}
    </style>


</HEAD>

<BODY>

<center><H1>Listar Pisos: </H1></center>

<?PHP

   // Conectar con el servidor de base de datos
      $conexion = mysqli_connect ("localhost", "root", "rootroot")
         or die ("No se puede conectar con el servidor");
		 
   // Seleccionar base de datos
      mysqli_select_db ($conexion,"inmobiliaria")
         or die ("No se puede seleccionar la base de datos");
   // Enviar consulta
      $instruccion = "select * from pisos";
      $consulta = mysqli_query ($conexion,$instruccion)
         or die ("Fallo en la consulta");
   // Mostrar resultados de la consulta
      $nfilas = mysqli_num_rows ($consulta);
      if ($nfilas > 0)
      {
         print ("<center><TABLE border='2px'>\n");
         print ("<TR>\n");
         print ("<TH>Codigo_piso</TH>\n");
         print ("<TH>Calle</TH>\n");
         print ("<TH>Numero</TH>\n");
         print ("<TH>Piso</TH>\n");
         print ("<TH>Puerta</TH>\n");
         print ("<TH>CP</TH>\n");
         print ("<TH>Metros</TH>\n");
         print ("<TH>Zona</TH>\n");
         print ("<TH>Precio</TH>\n");
         print ("<TH>Imagen</TH>\n");
         print ("<TH>Usuario_ID</TH>\n");
        
         print ("</TR></center>\n");

         for ($i=0; $i<$nfilas; $i++)
         {
            $resultado = mysqli_fetch_array ($consulta);
            print ("<TR>\n");
            print ("<TD>" . $resultado['Codigo_piso'] . "</TD>\n");
            print ("<TD>" . $resultado['calle'] . "</TD>\n");
            print ("<TD>" . $resultado['numero'] . "</TD>\n");
            print ("<TD>" . $resultado['piso'] . "</TD>\n");
            print ("<TD>" . $resultado['puerta'] . "</TD>\n");
            print ("<TD>" . $resultado['cp'] . "</TD>\n");
            print ("<TD>" . $resultado['metros'] . "</TD>\n");
            print ("<TD>" . $resultado['zona'] . "</TD>\n");
            print ("<TD>" . $resultado['precio'] . "</TD>\n");
            print ("<TD>" . "<img height = '150px'src='../img/". $resultado['imagen'] . "'>" . "</TD>\n"); 
            print ("<TD>" . $resultado['id'] . "</TD>\n");
            
   

         print("</TR>\n");
         }
         print ("</TABLE>\n");
      }
      else
         print ("No hay nada que mostrar");

// Cerrar 
mysqli_close ($conexion);

?>

<br><br><a href="usuarios_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>


</BODY>
</HTML>