CREATE DATABASE inmobiliaria;
use inmobiliaria;

CREATE TABLE usuario (
id int(5) NOT NULL AUTO_INCREMENT,
username varchar(35) NOT NULL,
email varchar(100) NOT NULL,
password varchar(80) NOT NULL,
role varchar(200),
primary key(id)
);

CREATE TABLE pisos (
Codigo_piso int primary key AUTO_INCREMENT,
calle VARCHAR(40) NOT NULL,
numero INT NOT NULL,
piso INT NOT NULL,
puerta VARCHAR(5) NOT NULL,
cp INT NOT NULL,
metros INT NOT NULL,
zona VARCHAR (15),
precio float NOT NULL,
imagen varchar(100) NOT NULL,
id int(5)references usuario
);

CREATE TABLE comprados (
usuario_comprador int(5)references usuario(id),
Codigo_piso int references pisos,
Precio_final float NOT NULL,
primary key(codigo_piso)
);