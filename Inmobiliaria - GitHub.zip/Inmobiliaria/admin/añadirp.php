
<?php
		
session_start();


if(isset($_SESSION['admin_login']))
{
?>
<?php
        $mail= $_SESSION['admin_login'];

}
// Conectar con el servidor de base de datos
   $conexion = mysqli_connect ("localhost", "root", "rootroot")
      or die ("No se puede conectar con el servidor");
  
// Seleccionar base de datos
   mysqli_select_db ($conexion,"inmobiliaria")
      or die ("No se puede seleccionar la base de datos");
// Enviar consulta
   $instruccion = "select * from usuario where email like '$mail'";
   $consulta = mysqli_query ($conexion,$instruccion)
      or die ("Fallo en la consulta");
// Mostrar resultados de la consulta
   $nfilas = mysqli_num_rows ($consulta);
   if ($nfilas == 1)
      {
         $resultado = mysqli_fetch_array ($consulta);   
      }
   
   else {
      print ("No hay noticias disponibles");
   }
// Cerrar 
mysqli_close ($conexion);

?>

<html>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">

		<link href="../css/bootstrap-theme.css" rel="stylesheet">

<HEAD>

<title>Añadir Pisos</title>

<meta charset="UTF-8">

<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

form{
    font-family: "Poppins", sans-serif;
    
    margin-left: 840px;
    margin-top: 60px;

}
h1{
    margin-top:40px;
    font-family: "Poppins", sans-serif;
}
    </style>


</HEAD>

<BODY>

<center><H2>Añadir Pisos:</H2></center>
 <form class="form-horizontal" action="añadirp1.php" method ="POST" enctype="multipart/form-data">

<div class="form-group">
<div class="col-sm-10">
Calle: <input type="text" class="form-control" placeholder ="calle" name="calle"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
Numero: <input type="text" class="form-control" placeholder ="numero" name="numero"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
Piso: <input type="text" class="form-control" placeholder ="piso" name="piso"><br><br>
</div>
<div class="form-group">
<div class="col-sm-10">
Puerta: <input type="text" class="form-control" placeholder ="puerta" name="puerta"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
C.P: <input type="text" class="form-control" placeholder ="C.P" name="cp"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
Metros: <input type="text" class="form-control" placeholder ="metros" name="metros"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
Zona: <input type="text" class="form-control" placeholder ="zona" name="zona"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
Precio: <input type="text" class="form-control" placeholder ="precio" name="precio"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
<INPUT TYPE="HIDDEN" class="form-control" NAME="MAX_FILE_SIZE" VALUE="110000">
</div>
</div>
<div class="form-group">
<div class="col-sm-10">
Imagen: <input type="file" class="form-control" placeholder ="imagen" name="imagen"><br><br>
</div>
</div>
<div class="form-group">
<div class="col-sm-10">

<input hidden  readonly type="text" value="<?php echo $resultado['id']; ?>" placeholder ="usuario id" name="usuarioid"><br><br>
<input type="submit" value="Añadir" class="btn btn-primary" name="añadir">
<a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>
</form>


</BODY>
</HTML>

