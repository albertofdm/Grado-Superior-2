<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>

<style>

body{
background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
color:black;
font-family: "Poppins", sans-serif;
}
h1{

   font-family: "Poppins", sans-serif;
}

    </style>

</head>

<body>

<center><h1>Añadir Usuarios</h1></center>

<?PHP


 $nombre= $_REQUEST["txtnombres"];
 $correo= $_REQUEST["txtcorreo"];
 $pass= $_REQUEST["txtpassword"];
 $pass=md5($pass);
 $role= $_REQUEST["role"];

 //Conectar con el servidor de base de datos 
 $conexion = mysqli_connect ("localhost", "root", "rootroot") or die ("No se puede conectar");
 //seleccionar base de datos
 mysqli_select_db ($conexion, "inmobiliaria") or die ("No se puede seleccionar la base de datos");

 $query ="insert into usuario(username,email,password,role) values('$nombre','$correo','$pass','$role')";
 //echo query; //Para insertar datos

 if (mysqli_query ($conexion,$query))
 {
    echo "<center>Usuario Dado de alta</center>";
 }
 else
 {
    echo "<center>Usuario No dado de alta</center>";
 }


 //cerrar
 mysqli_close ($conexion);

?>

<br><br><center><a href="añadiru.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a></center>