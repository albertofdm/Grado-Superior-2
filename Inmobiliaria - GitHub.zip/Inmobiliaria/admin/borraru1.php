<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>

<style>

body{
background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

    </style>
</head>

<body>

<center><h1>Borrar Usuario</h1></center>

<?PHP

 $id= $_REQUEST["id"];


 //Conectar con el servidor de base de datos 
 $conexion = mysqli_connect ("localhost", "root", "rootroot") or die ("No se puede conectar");
 //seleccionar base de datos
 mysqli_select_db ($conexion, "inmobiliaria") or die ("No se puede seleccionar la base de datos");

 $query ="delete from usuario where id like'$id'";
 //echo query; //Para eliminar datos

 if (mysqli_query ($conexion,$query))
 {
    echo "<center>El usuario ha sido eliminado de la Base de datos</center>";
 }
 else
 {
    echo "<center>El usuario no ha podido borrarse</center>";
 }


 //cerrar
 mysqli_close ($conexion);

?>
<br><br>
<center><a href="borraru.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a></center>