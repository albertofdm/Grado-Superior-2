<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>

<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

form{
    font-family: "Poppins", sans-serif;
    
    margin-left: 850px;
    margin-top: 60px;

}
h1{
    margin-top:40px;
    font-family: "Poppins", sans-serif;
}
    </style>

</head>

<center><h1> Buscar Pisos: </h1></center>
<form action="buscarp1.php" method="get">
  <p>Nombre de la calle: <input type="text" class="form-control"  placeholder="Escribe el nombre de la calle" name="codpiso" size="30"></p>

    <input type="submit"  class="btn btn-primary"="Enviar">
    <input type="reset" class="btn btn-primary"value="Borrar">
    <br><br><a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>
</form>

