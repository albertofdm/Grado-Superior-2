
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>


<style>

body{
background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}
form{

   font-family: "Poppins", sans-serif;
}
    </style>

</head>

<body>

<center><h1>Login Pisos</h1></center>

<?PHP

 $cod_piso= $_REQUEST["codpiso"];

 //Conectar con el servidor de base de datos 
 $conexion = mysqli_connect ("localhost", "root", "rootroot") or die ("No se puede conectar");
 //seleccionar base de datos
 mysqli_select_db ($conexion, "inmobiliaria") or die ("No se puede seleccionar la base de datos");

 $query ="select * from pisos where Codigo_piso='$cod_piso'";
 //Para comprobar errores de mysql

$consulta = mysqli_query ($conexion,$query) or die ("Fallo en la consulta");
//Mostrar resultados en la consulta
$nfilas = mysqli_num_rows ($consulta) ; // devuelve el numero de filas

if ($nfilas <> 1 )
{
   echo "Error";

}
   else 
{  $resultado = mysqli_fetch_array ($consulta);
   echo "<center>Codigo del piso correcto</center>";
   echo "<form action ='modificarp2.php' method='GET'>"."<br>";
   
   echo "<center>Codigo Piso Nuevo: <input type='text' class='form-control' name='codigopiso' value=".$resultado['Codigo_piso']."></center><br>";
   echo "<center>Precio: <input type='text' name='precio'class='form-control' value=".$resultado['precio']."></center><br>";
   echo "<center><input type='submit' class='btn btn-primary' value='Actualizar' name='entrar2'></center>";
   echo "</form";
} 
 //cerrar
 mysqli_close ($conexion);

?>

<br><br><center><a href="modificarp.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a></center>