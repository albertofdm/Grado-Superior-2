<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>
<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

h1{

   font-family: "Poppins", sans-serif;
}
    </style>
</head>
<br><br>


<?php

				
session_start();



if(isset($_SESSION['personal_login']))
{

        $mail= $_SESSION['personal_login'];


}

// Conectar con el servidor de base de datos
$conexion = mysqli_connect ("localhost", "root", "rootroot")
or die ("No se puede conectar con el servidor");

// Seleccionar base de datos
mysqli_select_db ($conexion,"inmobiliaria")
or die ("No se puede seleccionar la base de datos");
// Enviar consulta
$instruccion = "select * from usuario where email like '$mail'";
$consulta = mysqli_query ($conexion,$instruccion)
or die ("Fallo en la consulta");
// Mostrar resultados de la consulta
$nfilas = mysqli_num_rows ($consulta);
if ($nfilas == 1)
{
   $resultado = mysqli_fetch_array ($consulta); 
   $idcompra=  $resultado['id'];

}

else {
print ("No hay noticias disponibles");
}
// Cerrar 
mysqli_close ($conexion);

?>

<center><h1>Búsqueda De Pisos</h1></center><br><br><br>
<?php
  $cod=$_REQUEST['codpiso'];
  // Conectar con el servidor de base de datos
     $conexion = mysqli_connect ("localhost", "root", "rootroot")
        or die ("No se puede conectar con el servidor");
    
  // Seleccionar base de datos
     mysqli_select_db ($conexion,"inmobiliaria")
        or die ("No se puede seleccionar la base de datos");
  // Enviar consulta

   if ($cod=="") {
      $instruccion = "select * from pisos where Codigo_piso not in (select Codigo_piso from comprados);";
   }
   else {
      $instruccion = "select * from pisos where calle like '$cod' and Codigo_piso not in (select Codigo_piso from comprados);";
   }

     $consulta = mysqli_query ($conexion,$instruccion)
        or die ("Fallo en la consulta");
  // Mostrar resultados de la consulta
     $nfilas = mysqli_num_rows ($consulta);
     if ($nfilas > 0)
     {
       print ("<form action='../personal/comprarp1.php'>");
       print ("<center><TABLE border='3px'>\n");
        print ("<TR>\n");
        print ("<TH>Selecciona</TH>\n");
        print ("<TH>Codigo_piso</TH>\n");
        print ("<TH>Calle</TH>\n");
        print ("<TH>Numero</TH>\n");
        print ("<TH>Piso</TH>\n");
        print ("<TH>Puerta</TH>\n");
        print ("<TH>CP</TH>\n");
        print ("<TH>Metros</TH>\n");
        print ("<TH>Zona</TH>\n");
        print ("<TH>Precio</TH>\n");
        print ("<TH>Imagen</TH>\n");
        print ("<TH>Usuario_ID</TH>\n");
       
        print ("</TR></center>\n");

        for ($i=0; $i<$nfilas; $i++)
        {
           $resultado = mysqli_fetch_array ($consulta);
           print ("<TR>\n");
           print ("<TD> <input type='radio' name='elegido' value='". $resultado['Codigo_piso']." ' </TD>\n");
           print ("<TD>" . $resultado['Codigo_piso'] . "</TD>\n");
           print ("<TD>" . $resultado['calle'] . "</TD>\n");
           print ("<TD>" . $resultado['numero'] . "</TD>\n");
           print ("<TD>" . $resultado['piso'] . "</TD>\n");
           print ("<TD>" . $resultado['puerta'] . "</TD>\n");
           print ("<TD>" . $resultado['cp'] . "</TD>\n");
           print ("<TD>" . $resultado['metros'] . "</TD>\n");
           print ("<TD>" . $resultado['zona'] . "</TD>\n");
           print ("<TD>" . $resultado['precio'] . "</TD>\n");
           print ("<TD>" . "<img height = '150px'src='../img/". $resultado['imagen'] . "'>" . "</TD>\n"); 
           print ("<TD>" . $resultado['id'] . "</TD>\n");
           print ("<TD> <input hidden readonly type='text' name='user' value='". $idcompra ." '  </td><td> </TD>\n");
           print ("<TD> <input hidden readonly type='text' name='preciofinal' value='". $resultado['precio']." '  </td><td> </TD>\n");

           
  

        print("</TR>\n");
        }
       
        print ("</TABLE>\n");
        print("<br><br>");
        print ('<p><input type="submit" class="btn btn-primary" value="Comprar" name="Comprar"></p>');
        print ("</form>");
     }
     else
        print ("<center>No hay nada que mostrar</center>");
// Cerrar 
mysqli_close ($conexion);

?>

<br><br><center><a href="buscarp.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a></center><br><br>