<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<head>
  
<style>

body{
    background-color: #c1bdba;
color:black;
font-family: "Poppins", sans-serif;
}


h1{
    font-family: "Poppins", sans-serif;
    margin-top:40px;
}
    </style>
</head>

<center><H1>Listar Usuarios:</H1></center><br><br>

<?PHP

   // Conectar con el servidor de base de datos
      $conexion = mysqli_connect ("localhost", "root", "rootroot")
         or die ("No se puede conectar con el servidor");
		 
   // Seleccionar base de datos
      mysqli_select_db ($conexion,"inmobiliaria")
         or die ("No se puede seleccionar la base de datos");
   // Enviar consulta
      $instruccion = "select id,username,email,password,role from usuario";
      $consulta = mysqli_query ($conexion,$instruccion)
         or die ("Fallo en la consulta");
   // Mostrar resultados de la consulta
      $nfilas = mysqli_num_rows ($consulta);
      if ($nfilas > 0)
      {
        print("<br><br><br><br><br><br>");
         print ("<center><TABLE border='3px'>\n");
         print ("<TR>\n");
         print ("<TH>ID Usuario</TH>\n");
         print ("<TH>Nombre</TH>\n");
         print ("<TH>Correo</TH>\n");
         print ("<TH>Contraseña</TH>\n");;
         print ("<TH>Role</TH></center>\n");
        
         print ("</TR>\n");

         for ($i=0; $i<$nfilas; $i++)
         {
            $resultado = mysqli_fetch_array ($consulta);
            print ("<TR>\n");
            print ("<TD>" . $resultado['id'] . "</TD>\n");
            print ("<TD>" . $resultado['username'] . "</TD>\n");
            print ("<TD>" . $resultado['email'] . "</TD>\n");
            print ("<TD>" . $resultado['password'] . "</TD>\n");
            print ("<TD>" . $resultado['role'] . "</TD>\n");

         print("</TR>\n");
         }
         print ("</TABLE>\n");
      }
      else
         print ("No hay usuarios que mostrar");

// Cerrar 
mysqli_close ($conexion);

?>
<br><BR>
<a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a