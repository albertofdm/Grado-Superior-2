<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>

<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

form{

   font-family: "Poppins", sans-serif;
    margin-left: 850px;
    margin-top: 60px;

}
h1{
   font-family: "Poppins", sans-serif;
    margin-top:40px;
}
    </style>


</head>

<body>

<center><h1>Añadir Pisos</h1></center>

<?PHP

 $codigo_piso= $_REQUEST["codigopiso"];
 $calle= $_REQUEST["calle"];
 $numero= $_REQUEST["numero"];
 $piso= $_REQUEST["piso"];
 $puerta= $_REQUEST["puerta"];
 $cp= $_REQUEST["cp"];
 $metros= $_REQUEST["metros"];
 $zona= $_REQUEST["zona"];
 $precio= $_REQUEST["precio"];
 $imagen= $_REQUEST["imagen"];
 $usuarioid= $_REQUEST["usuarioid"];

 //Conectar con el servidor de base de datos 
 $conexion = mysqli_connect ("localhost", "root", "rootroot") or die ("No se puede conectar");
 //seleccionar base de datos
 mysqli_select_db ($conexion, "inmobiliaria") or die ("No se puede seleccionar la base de datos");



 // Subir fichero
 $copiarFichero = false;

 if (is_uploaded_file ($_FILES['imagen']['tmp_name']))
 {
    $nombreDirectorio = "C:/AppServ/www/inmobiliaria/img";
    $nombreFichero = $_FILES['imagen']['name'];
    $copiarFichero = true;

 // Si ya existe un fichero con el mismo nombre, renombrarlo
    $nombreCompleto = $nombreDirectorio . $nombreFichero;
    
  if (is_file($nombreCompleto))
    {

       $nombreFichero = $nombreFichero;
    echo  "---".$nombreFichero."---";
    }
 }
// El fichero introducido supera el límite de tamaño permitido
 else if ($_FILES['imagen']['error'] == UPLOAD_ERR_FORM_SIZE)
 {
     $maxsize = $_REQUEST['MAX_FILE_SIZE'];
    $errores = $errores . "<LI>El tamaño del fichero supera el límite permitido ($maxsize bytes)\n";
    $nombreFichero = '';
 }
// No se ha introducido ningún fichero
 else if ($_FILES['imagen']['name'] == "")
    $nombreFichero = '';
// El fichero introducido no se ha podido subir
 else
 {
    $errores = $errores . "<LI>No se ha podido subir el fichero\n";
    $nombreFichero = '';
 }

// Mover fichero de imagen a su ubicación definitiva
 if ($copiarFichero)
    move_uploaded_file ($_FILES['imagen']['tmp_name'],
    $nombreDirectorio . $nombreFichero);


   
       $query ="insert into pisos(Codigo_piso,calle,numero,piso,puerta,cp,metros,zona,precio,imagen,id) values('$codigo_piso','$calle','$numero','$piso','$puerta','$cp','$metros','$zona','$precio','$nombreFichero','$usuarioid')";
       //echo query; //Para insertar datos
      
       if (mysqli_query ($conexion,$query))
       {
          echo "<center>Se han añadido los datos del piso a la base de datos</center>";
       }
       else
       {
          echo "<center>No se han podido añadir a la base de datos los datos del piso</center>";
       }


 //cerrar
 mysqli_close ($conexion);



?>
<br><br><center><a href="añadirp.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a></center>
