<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>

<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);

color:black;
}

form{

    
    margin-left: 850px;
    margin-top: 60px;

}
h1{
    margin-top:40px;
}
    </style>

</head>

<center><h1> Borrar Pisos: </h1></center>
<form action="borrarp1.php" method="get">
  <p>Código del piso: <input type="text" class="form-control" placeholder name="codpiso" size="25"></p>

    <input type="submit"class="btn btn-primary"  value="Borrar">
    <a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>
</form>

