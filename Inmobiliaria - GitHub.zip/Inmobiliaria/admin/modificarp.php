<html>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<HEAD>

<title>Actualizar</title>

<meta charset="UTF-8">
<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

form{

    font-family: "Poppins", sans-serif;
    margin-left: 850px;
    margin-top: 60px;

}
h1{
    font-family: "Poppins", sans-serif;
    margin-top:40px;
}
    </style>

</HEAD>

<BODY>

<center><H2>Modificar Pisos:</H2></center>
<form action="modificarp1.php" method ="POST">
<p>Introduce el Código del piso: <input type="text" class="form-control"   placeholder="Introduce el codigo del piso..." name="codpiso"></p><br><br>
<input type="submit" value="Actualizar" class="btn btn-primary" name name="entrar">
<br><br><a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>
</form>



</BODY>
</HTML>
