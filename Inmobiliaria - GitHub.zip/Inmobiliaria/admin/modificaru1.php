<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<head>

<style>

body{
background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

    </style>

</head>

<body>

<center><h1>Login usuario</h1></center><br><br>

<?PHP

 $nombre= $_REQUEST["txtusuario"];

 //Conectar con el servidor de base de datos 
 $conexion = mysqli_connect ("localhost", "root", "rootroot") or die ("No se puede conectar");
 //seleccionar base de datos
 mysqli_select_db ($conexion, "inmobiliaria") or die ("No se puede seleccionar la base de datos");

 $query ="select * from usuario where username='$nombre'";
//Para comprobar errores de mysql

$consulta = mysqli_query ($conexion,$query) or die ("Fallo en la consulta");
//Mostrar resultados en la consulta
$nfilas = mysqli_num_rows ($consulta) ; // devuelve el numero de filas

if ($nfilas <> 1 )
{
   echo "Error, algun dato es incorrecto.";

}
   else 
{  $resultado = mysqli_fetch_array ($consulta);
   echo "<center>Usuario Correcto</center><br>";
   echo "<form action ='modificaru2.php' method='GET'>";
   echo "<center>Nombre: <input type='text' class='form-control' name='txtnombre' value=".$resultado['username']."></center><br>";
   echo "<center>Clave: <input type='text' readonly class='form-control' name='txtclave' value=".$resultado['password']."></center><br>";
   echo "<input type='hidden' name='txtid' value=".$resultado['id']."><br>";
   echo "<center><input type='submit' class='btn btn-primary'  value='Actualizar' name='entrar2'></center>";
   echo "</form";
} 
 //cerrar
 mysqli_close ($conexion);

?>
<br><br><center><a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a></center>