<html>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/bootstrap-theme.css" rel="stylesheet">
<HEAD>

<title>Actualizar</title>

<meta charset="UTF-8">

<style>

body{
    background-color: #0093E9;
background-image: linear-gradient(160deg, #0093E9 0%, #80D0C7 100%);
font-family: "Poppins", sans-serif;
color:black;
}

form{

    font-family: "Poppins", sans-serif;
    margin-left: 760px;
    margin-top: 60px;

}
h1{
    font-family: "Poppins", sans-serif;
    margin-top:40px;
}
    </style>

</HEAD>

<BODY>

<center><H1>Modificar Usuarios:</H1></center>
<form action="modificaru1.php" method ="POST">
<p>Introduce un nombre:<input type="text" class="form-control" placeholder="nombre" name="txtusuario"></p><br><br>
<input type="submit" value="Actualizar" class="btn btn-primary" name="entrar">
<a href="admin_portada.php"><input type="" value="Volver" class="btn btn-primary" name="volver"></a>
</form>



</BODY>
</HTML>
